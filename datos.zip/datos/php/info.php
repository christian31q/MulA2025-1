<?php
    echo phpinfo();
?>