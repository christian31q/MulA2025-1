<?php
 // Get POST data from raw input stream
 $jsonData = file_get_contents('php://input');

 // Decode JSON data
$decodedData = json_decode($jsonData, true);



 //$encodedData = json_encode($decodedData, true);

 //echo  $encodedData;
            
 //$mysqli = new mysqli("localhost", "root", "", "mula"); // datos del servidor local
 $mysqli = new mysqli("sql301.infinityfree.com", "if0_38853035", "TT3bvox7gT", "if0_38853035_mula");

/*if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
} else {
    echo "Connected successfully";
}*/

$correo = $decodedData['correo'];
$contrasena = $decodedData['contrasena'];

$sql = "INSERT INTO `usuario` (`id`, `correo`, `contrasena`) VALUES (NULL, '". $correo ."', '". $contrasena ."');";

if ($mysqli->query($sql) === TRUE) {
    echo "ok";  
} else {
    echo "fail";
}


$mysqli->close();

 

 //echo  $decodedData;
    
?>